package com.company.interfaces;

import java.rmi.Remote;

public interface ClientInterface extends Remote {


}
