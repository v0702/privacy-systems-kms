package com.company.interfaces;

import java.rmi.Remote;

public interface OperatorInterface extends Remote {


}
