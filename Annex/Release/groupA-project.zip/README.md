Source code for privacy-systems-kms.
Release and further notes on github repo:
https://github.com/v0702/privacy-systems-kms
