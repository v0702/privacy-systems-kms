# Python Module ciphersuite
import os
import random
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

# Security parameter (fixed)
KEYLEN = 16

# A service for generating keys and 
class hsm:
	# (1) added list of key and an
	keys = []
	id_counter = 0;

	def gen(): 
		# (1) 
		id_counter += 1
		keys.append((os.urandom(KEYLEN), id_counter))
		return id_counter;

	def enc(given_key_id, m): # (2) changed input from key to the key identifier
		# (3) get the key from our structure that stores it
		k = keys[given_key_id][0]
		nonce = os.urandom(KEYLEN)
		cipher = Cipher(algorithms.AES(k), modes.CTR(nonce))
		encryptor = cipher.encryptor()
		cph = b""
		cph += encryptor.update(m)
		cph += encryptor.finalize()
		return (cph,nonce)

	def dec(given_key_id, c, nonce): # (2) changed input from key to the key identifier
		# (3) get the key from our structure that stores it
		k = keys[given_key_id][0]
		cipher = Cipher(algorithms.AES(k), modes.CTR(nonce))
		decryptor = cipher.decryptor()
		msg = b""
		msg += decryptor.update(c)
		msg += decryptor.finalize()
		return msg

# Trying out my hsm encryption service
# (4) Testing the functions should be adapted, too
key_id = hsm.gen()

# Encryption test
msg = b'Test message !!!'
(cph,nonce) = hsm.enc(key_id, msg)
print("Here is my ciphertext:")
print(cph)
print('\n')

# Decryption test
msg_dec = hsm.dec(key_id, cph, nonce)
print("Original message:")
print(msg)
print('\n')
print("Decrypted message:")
print(msg_dec)
print('\n')

# Final check
if (msg == msg_dec):
	print("All seems well!")
else:
	print("Error!")
